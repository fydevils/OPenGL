//
//  main.cpp
//  OpenGL
//
//  Created by 李娜 on 2019/5/28.
//  Copyright © 2019 李娜. All rights reserved.
//

#include <stdio.h>

#include "GLShaderManager.h"//固定管线的管理器（管线分固定管线和可编程管线）

#include "GLTools.h"

#include <glut/glut.h>


#define GL_SILENCE_DEPRECATION

GLBatch triangleBatch;
GLfloat blockSize = 0.1f;

GLfloat vVerts[] = {
    
    -blockSize,-blockSize,0.0f,
    blockSize,-blockSize,0.0f,
    blockSize,blockSize,0.0f,
    -blockSize,blockSize,0.0f,
};

//x y移动的距离
GLfloat xPos = 0.0f;
GLfloat yPos = 0.0f;
GLShaderManager shaderManager;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
//窗口大小改变时接受新的宽度和高度，其中0,0代表窗口中视口的左下角坐标，w，h代表像素

void ChangeSize(int w,int h) {
    
    glViewport(0,0, w, h);
    
}

//为程序作一次性的设置

void SetupRC() {
    
    //设置背景颜色
    
    glClearColor(0.0f,0.0f,1.0f,1.0f);
    
    //初始化着色管理器
    
    shaderManager.InitializeStockShaders();
    
    //批次处理
    triangleBatch.Begin(GL_TRIANGLE_FAN,4);
    triangleBatch.CopyVertexData3f(vVerts);
    triangleBatch.End();
    
}

//开始渲染

void RenderScene(void) {
    
    //清除一个或一组特定的缓冲区  背景颜色
    
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);
    
    //设置一组浮点数来表示红色，红绿蓝，透明度 范围是0-1
    
    GLfloat vRed[] = {1.0f,0.0f,0.0f,1.0f};
    
    //矩阵--3D数学（开发角度） Matrix矩阵  44f指4行4列
    // 最终结果  平移矩阵 旋转矩阵
    M3DMatrix44f mFinalTransform,mTransformMatrix,mRotationMatrix;

    //平移  xyz移动的距离
    m3dTranslationMatrix44(mTransformMatrix, xPos, yPos, 0);
    //旋转
    static float yPot = 0.0f;//角度
    yPot += 5.0f;
    m3dRotationMatrix44(mRotationMatrix, m3dDegToRad(yPot), 0.0f, 0.0f, 1.0f);//m3dDegToRad(yPot)度数转弧度

    //2个结果矩阵！！！矩阵相乘
    m3dMatrixMultiply44(mFinalTransform, mTransformMatrix, mRotationMatrix);

    shaderManager.UseStockShader(GLT_SHADER_FLAT,mFinalTransform,vRed);

    //传递到存储着色器，即GLT_SHADER_IDENTITY着色器，这个着色器只是使用指定颜色以默认笛卡尔坐标第在屏幕上渲染几何图形 （用固定管线）
    
  //   SHADER_IDENTITY,vRed);
    
    //提交着色器
    
    triangleBatch.Draw();
    
    //将在后台缓冲区进行渲染，然后在结束时交换到前台
    
    glutSwapBuffers();
}



void SpeacialKeys(int key,int x,int y) {
    /*
     GLfloat stepSize = 0.025f;//移步步长
     //拿到D点的X Y值
     GLfloat blockX = vVerts[0];
     GLfloat blockY = vVerts[10];
     if (key == GLUT_KEY_UP) {
     blockY += stepSize;
     }
     if (key == GLUT_KEY_DOWN) {
     blockY -= stepSize;
     }
     if (key == GLUT_KEY_RIGHT) {
     blockX += stepSize;
     }
     if (key == GLUT_KEY_LEFT) {
     blockX -= stepSize;
     }
     //限制边界
     if (blockX < -1.0f) {
     blockX = -1.0f;
     }
     if (blockX > (1.0 - blockSize * 2)) {
     blockX = 1.0 - blockSize * 2;
     }
     
     if (blockY < -1.0f +  blockSize * 2) {
     blockY =  -1.0f +  blockSize * 2;
     }
     
     if (blockY > 1.0f) {
     blockY = 1.0f;
     }
     
     //修改顶点
     vVerts[0] = blockX;
     vVerts[1] = blockY - blockSize * 2;
     
     vVerts[3] = blockX + blockSize *2;
     vVerts[4] = blockY - blockSize * 2;
     
     vVerts[6] = blockX + blockSize *2;
     vVerts[7] = blockY;
     
     vVerts[9] = blockX;
     vVerts[10] = blockY;
     
     //提交顶点
     triangleBatch.CopyVertexData3f(vVerts);
     glutPostRedisplay();
     */
    
    GLfloat stepSize = 0.025f;//移步步长
    if (key == GLUT_KEY_UP) {
        yPos += stepSize;
    }
    if (key == GLUT_KEY_DOWN) {
        yPos -= stepSize;
    }
    if (key == GLUT_KEY_RIGHT) {
        xPos += stepSize;
    }
    if (key == GLUT_KEY_LEFT) {
        xPos -= stepSize;
    }
    //碰撞检测
    if (xPos < -1.0f + blockSize) {
        xPos =  -1.0f + blockSize;
    }
    if (xPos > 1.0f - blockSize) {
        xPos = 1.0f - blockSize;
    }
    if (yPos > 1.0f -blockSize) {
        yPos = 1.0f -blockSize;
    }
    if (yPos < -1.0f + blockSize) {
        yPos = -1.0f + blockSize;
    }
    
    glutPostRedisplay();
}

int main(int argc,char* argv[]) {
    
    //设置当前工作目录，针对MAC OS X
    
    gltSetWorkingDirectory(argv[0]);
    
    //初始化GLUT库
    glutInit(&argc, argv);
    
    /*初始化双缓冲窗口，其中标志GLUT_DOUBLE、GLUT_RGBA、GLUT_DEPTH、GLUT_STENCIL分别指
     
     双缓冲窗口、RGBA颜色模式、深度测试、模板缓冲区*/
    
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGBA|GLUT_DEPTH|GLUT_STENCIL);
    
    //GLUT窗口大小，标题窗口
    glutInitWindowSize(800,600);
    
    glutCreateWindow("Square");//根据前面设置的信息创建窗口
    
    //注册回调函数
    
    glutReshapeFunc(ChangeSize);
    
    //当需要画图时，请调用Display函数
    glutDisplayFunc(RenderScene);
    
    glutSpecialFunc(SpeacialKeys);
    //驱动程序的初始化中没有出现任何问题。
    GLenum err = glewInit();
    
    if(GLEW_OK != err) {
        
        fprintf(stderr,"glew error:%s\n",glewGetErrorString(err));
        
        return 1;
        
    }
    
    //调用SetupRC
    
    SetupRC();
    
    glutMainLoop();
    
    return 0;
    
}

#pragma clang diagnostic pop
